I wasn't able to figure out a seg fault in my code. 

compile: g++ activity.cpp -o act

Run: ./act